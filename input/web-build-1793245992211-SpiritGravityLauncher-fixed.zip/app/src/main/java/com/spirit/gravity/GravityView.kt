package com.spirit.gravity

import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class GravityView(
    context: Context,
    private val onAppTap: (String) -> Unit
) : View(context) {

    private data class AppItem(
        val label: String,
        val packageName: String,
        val icon: Drawable,
        var x: Float = 0f,
        var y: Float = 0f,
        var vx: Float = 0f,
        var vy: Float = 0f,
        var settled: Boolean = false
    )

    var physicsEnabled = true
    private val items = mutableListOf<AppItem>()
    private val iconSize = dp(54f)
    private val bodyRadius get() = iconSize * 0.43f
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = dp(11f)
        textAlign = Paint.Align.CENTER
        setShadowLayer(dp(3f), 0f, dp(1f), Color.BLACK)
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(90, 96, 115)
        textSize = dp(13f)
        textAlign = Paint.Align.CENTER
    }
    private val groundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 50, 75)
        strokeWidth = dp(2f)
    }
    private val hitRect = RectF()
    private var tiltX = 0f
    private var tiltY = 0f
    private var lastTime = 0L
    private var initializedPositions = false

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        reloadApps()
    }

    fun reloadApps() {
        val pm = context.packageManager
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN, null).apply {
            addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(intent, 0)
        val found = resolved
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .mapNotNull { info ->
                try {
                    AppItem(
                        info.loadLabel(pm).toString(),
                        info.activityInfo.packageName,
                        info.loadIcon(pm)
                    )
                } catch (_: Exception) { null }
            }
            .sortedBy { it.label.lowercase() }

        val oldPositions = items.associateBy { it.packageName }
        items.clear()
        items.addAll(found)
        if (width > 0 && height > 0) {
            items.forEachIndexed { index, item ->
                val old = oldPositions[item.packageName]
                if (old != null) {
                    item.x = old.x; item.y = old.y
                    item.vx = old.vx; item.vy = old.vy
                } else placeInGrid(item, index)
            }
            initializedPositions = true
        }
        invalidate()
    }

    fun setTilt(x: Float, y: Float) {
        tiltX = x
        tiltY = y
        if (physicsEnabled) postInvalidateOnAnimation()
    }

    fun resetPositions() {
        items.forEachIndexed { index, item ->
            placeInGrid(item, index)
            item.vx = 0f
            item.vy = 0f
            item.settled = false
        }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        items.forEachIndexed { index, item -> placeInGrid(item, index) }
        initializedPositions = true
    }

    private fun placeInGrid(item: AppItem, index: Int) {
        if (width <= 0 || height <= 0) return
        val spacing = dp(82f)
        val columns = max(1, (width / spacing).toInt())
        val col = index % columns
        val row = index / columns
        item.x = dp(42f) + col * spacing
        item.y = dp(54f) + row * dp(104f)
        item.vx = 0f
        item.vy = 0f
        item.settled = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(8, 9, 13))
        if (items.isEmpty()) {
            canvas.drawText("No launchable apps found", width / 2f, height / 2f, hintPaint)
            return
        }

        val now = System.nanoTime()
        val dt = if (lastTime == 0L) 0.016f else ((now - lastTime) / 1_000_000_000f).coerceIn(0.001f, 0.032f)
        lastTime = now
        if (physicsEnabled && initializedPositions) simulate(dt)

        // Subtle floor marker indicates where icons settle.
        canvas.drawLine(dp(16f), height - dp(10f), width - dp(16f), height - dp(10f), groundPaint)

        items.forEach { item ->
            val left = item.x - iconSize / 2f
            val top = item.y - iconSize / 2f
            val save = canvas.save()
            canvas.translate(left, top)
            try {
                item.icon.setBounds(0, 0, iconSize.toInt(), iconSize.toInt())
                item.icon.alpha = 255
                item.icon.draw(canvas)
            } catch (_: Exception) {}
            canvas.restoreToCount(save)

            val shortLabel = if (item.label.length > 12) item.label.take(11) + "…" else item.label
            canvas.drawText(shortLabel, item.x, item.y + iconSize / 2f + dp(15f), labelPaint)
        }

        if (physicsEnabled) postInvalidateOnAnimation()
    }

    private fun simulate(dt: Float) {
        val r = bodyRadius
        val minX = r + dp(4f)
        val maxX = max(minX, width - r - dp(4f))
        val minY = r + dp(4f)
        val floorY = height - dp(10f) - r

        // Convert phone tilt to screen gravity. Clamp to avoid extreme jumps.
        val gx = (-tiltX * 95f).coerceIn(-700f, 700f)
        val gy = (-tiltY * 95f).coerceIn(-700f, 700f)

        for (item in items) {
            item.vx = (item.vx + gx * dt) * 0.992f
            item.vy = (item.vy + gy * dt + 500f * dt) * 0.992f
            item.x += item.vx * dt
            item.y += item.vy * dt

            if (item.x < minX) { item.x = minX; item.vx = abs(item.vx) * 0.42f }
            if (item.x > maxX) { item.x = maxX; item.vx = -abs(item.vx) * 0.42f }
            if (item.y < minY) { item.y = minY; item.vy = abs(item.vy) * 0.35f }
            if (item.y > floorY) {
                item.y = floorY
                item.vy = if (abs(item.vy) < 45f) 0f else -abs(item.vy) * 0.24f
                item.vx *= 0.90f
            }
        }

        // Lightweight circle collisions. Icons are treated as soft physics bodies.
        for (i in 0 until items.size) {
            for (j in i + 1 until items.size) {
                val a = items[i]
                val b = items[j]
                var dx = b.x - a.x
                var dy = b.y - a.y
                val distance2 = dx * dx + dy * dy
                val minDistance = r * 1.72f
                if (distance2 < minDistance * minDistance) {
                    var distance = kotlin.math.sqrt(max(0.01f, distance2))
                    if (distance < 0.01f) {
                        dx = 0.1f; dy = 0.1f; distance = 0.141f
                    }
                    val nx = dx / distance
                    val ny = dy / distance
                    val overlap = minDistance - distance
                    a.x -= nx * overlap * 0.5f
                    a.y -= ny * overlap * 0.5f
                    b.x += nx * overlap * 0.5f
                    b.y += ny * overlap * 0.5f
                    val relative = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny
                    if (relative < 0f) {
                        val impulse = -relative * 0.28f
                        a.vx -= impulse * nx; a.vy -= impulse * ny
                        b.vx += impulse * nx; b.vy += impulse * ny
                    }
                    a.x = a.x.coerceIn(minX, maxX)
                    b.x = b.x.coerceIn(minX, maxX)
                    a.y = a.y.coerceIn(minY, floorY)
                    b.y = b.y.coerceIn(minY, floorY)
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val x = event.x
                val y = event.y
                val tapped = items.minByOrNull {
                    val dx = it.x - x
                    val dy = it.y - y
                    dx * dx + dy * dy
                }
                if (tapped != null) {
                    val dx = tapped.x - x
                    val dy = tapped.y - y
                    if (dx * dx + dy * dy < (iconSize * 0.8f) * (iconSize * 0.8f)) {
                        onAppTap(tapped.packageName)
                    }
                }
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
