package com.spirit.gravity

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var gravityView: GravityView
    private var physicsEnabled = true
    private var filteredX = 0f
    private var filteredY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 9, 13)
        window.navigationBarColor = Color.rgb(8, 9, 13)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 9, 13))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }

        val title = TextView(this).apply {
            text = "spirit"
            textSize = 26f
            setTextColor(Color.rgb(255, 55, 78))
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))

        val reset = TextView(this).apply {
            text = "RESET"
            textSize = 12f
            letterSpacing = 0.08f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { gravityView.resetPositions() }
        }
        header.addView(reset)

        val toggle = TextView(this).apply {
            text = "PHYSICS ON"
            textSize = 12f
            letterSpacing = 0.03f
            setTextColor(Color.rgb(255, 100, 115))
            setPadding(dp(12), dp(10), 0, dp(10))
            setOnClickListener {
                physicsEnabled = !physicsEnabled
                text = if (physicsEnabled) "PHYSICS ON" else "PHYSICS OFF"
                setTextColor(if (physicsEnabled) Color.rgb(255, 100, 115) else Color.LTGRAY)
                gravityView.physicsEnabled = physicsEnabled
            }
        }
        header.addView(toggle)

        gravityView = GravityView(this) { packageName ->
            try {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                } else {
                    Toast.makeText(this, "Can't open this app", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                Toast.makeText(this, "Couldn't open app", Toast.LENGTH_SHORT).show()
            }
        }

        root.addView(header)
        root.addView(gravityView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val footer = TextView(this).apply {
            text = "TILT YOUR PHONE  •  TAP AN ICON TO OPEN"
            textSize = 10f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(135, 140, 155))
            setPadding(dp(12), dp(10), dp(12), dp(16))
        }
        root.addView(footer)
        setContentView(root)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (accelerometer == null) {
            Toast.makeText(this, "No accelerometer found; touch interaction still works", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        if (::gravityView.isInitialized) gravityView.reloadApps()
    }

    override fun onPause() {
        super.onPause()
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        // Low-pass filter reduces sensor jitter. Android's axes are device-relative.
        filteredX = filteredX * 0.78f + event.values[0] * 0.22f
        filteredY = filteredY * 0.78f + event.values[1] * 0.22f
        if (::gravityView.isInitialized) gravityView.setTilt(filteredX, filteredY)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
