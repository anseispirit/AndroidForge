# Spirit Gravity Launcher

A starter Android Studio project for a gravity-based Android home screen.

## Features
- Can be selected as the Android HOME launcher.
- Lists launchable apps and opens them when tapped.
- Accelerometer-driven gravity, simple icon collisions, floor settling.
- Reset positions and physics on/off controls.
- Black/red Spirit styling.

## Build an APK
1. Install Android Studio on your Windows PC.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `SpiritGravityLauncher` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and JDK 17.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Install the generated APK on your Galaxy. You may need to allow installs from the app used to open the APK.
7. Open Spirit Gravity, then press Home and choose **Spirit Gravity**. Choose **Always** only if you want it as your default launcher.

## Notes
- This is a starter project, not a tested prebuilt APK. The APK must be compiled with Android Studio.
- Android launcher APIs and icon visibility can vary by One UI / Android version. Some apps may not appear because of system package-visibility rules or work-profile restrictions.
- It uses a lightweight circle-based collision approximation, not a full rigid-body physics engine.
- If Android Studio reports a Gradle/SDK issue, copy the exact error and send it back.
- To return to Samsung's home screen, go to Settings > Apps > Choose default apps > Home app and select One UI Home.


## GitHub Actions build
The project includes `gradle/wrapper/gradle-wrapper.properties` pinned to Gradle 8.9 and a workflow at `.github/workflows/build.yml`.
Upload the extracted project to a GitHub repository, then open **Actions** and run **Build Spirit Gravity APK**. Download the `SpiritGravity-debug-apk` artifact from the completed run.
